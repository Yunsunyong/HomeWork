package ncs.test10;

public interface Bonus {
	public void incentive(int pay);
}
